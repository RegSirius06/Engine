package com.example;

import net.regsirius06.engine.API.Core;
import net.regsirius06.engine.API.annotations.ImplementationOf;
import net.regsirius06.engine.API.annotations.ModId;
import net.regsirius06.engine.plugins.loaders.ExecutablesPluginLoader;

@ModId("Example")
@ImplementationOf(Core.class)
public class Example implements Core {
    @Override
    public ExecutablesPluginLoader getExecutables() {
        return new ExecutablesPluginLoader(this.getClass());
    }
}
